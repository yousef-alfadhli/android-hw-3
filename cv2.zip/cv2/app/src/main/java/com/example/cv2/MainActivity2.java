package com.example.cv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final TextView H = findViewById(R.id.X);
        final TextView J = findViewById(R.id.Y);
        final TextView C = findViewById(R.id.Z);
        final TextView V = findViewById(R.id.W);
        final TextView G = findViewById(R.id.T);
        Button F = findViewById(R.id.button);
        Bundle airport = getIntent().getExtras();

        String hh = airport.getString("x");
        String jj = airport.getString("y");
        String cc = airport.getString("z");
        String vv = airport.getString("w");
        String gg = airport.getString("t");


        H.setText(hh);
        J.setText(jj);
        C.setText(hh);
        V.setText(jj);
        G.setText(jj);

        F.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(MainActivity2.this, MainActivity.class);

                startActivity(intent);
            }
        });
    }
}