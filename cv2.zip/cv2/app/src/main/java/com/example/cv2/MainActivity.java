package com.example.cv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText x = findViewById(R.id.EditText);
        final EditText y = findViewById(R.id.EditText2);
        final EditText z = findViewById(R.id.EditText3);
        final EditText w = findViewById(R.id.EditText4);
        final EditText t = findViewById(R.id.EditText5);
        Button next =findViewById(R.id.button);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameInEditText = x.getText().toString();
                String ageInEditText = y.getText().toString();
                String jobInEditText = z.getText().toString();
                String phoneNumberInEditText = w.getText().toString();
                String emailInEditText = t.getText().toString();

                Intent intent = new Intent(MainActivity.this, MainActivity2.class );

                intent.putExtra("x" ,nameInEditText);
                intent.putExtra("y" ,ageInEditText);
                intent.putExtra("z" ,jobInEditText);
                intent.putExtra("w" ,phoneNumberInEditText);
                intent.putExtra("t" ,emailInEditText);

                startActivity(intent);









            }
        });




    }
}